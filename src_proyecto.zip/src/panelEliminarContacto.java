
import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class panelEliminarContacto extends  JPanel{
    private JTextField txtNombreaBuscar;
    private JTextField txtNumeroaBuscar;
    private Directorio directorio;

    public panelEliminarContacto(Directorio directorio){
        this.directorio = directorio;
    }


}
